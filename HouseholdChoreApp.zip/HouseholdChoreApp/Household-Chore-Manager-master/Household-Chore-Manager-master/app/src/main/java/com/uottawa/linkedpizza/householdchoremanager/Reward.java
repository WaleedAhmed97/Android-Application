package com.uottawa.linkedpizza.householdchoremanager;



public class Reward {
    private int points;

    // No reward by default.
    Reward(){
        points = 0;
    }
    Reward(int points){
        this.points = points;
    }

    public void setPoints(int points){
        this.points = points;
    }

    public int getPoints(){
        return points;
    }
}